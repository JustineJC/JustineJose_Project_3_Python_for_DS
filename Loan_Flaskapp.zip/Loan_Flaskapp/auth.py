from flask import Blueprint,render_template,request,flash,redirect,url_for
from werkzeug.security import generate_password_hash,check_password_hash #secure pwd with hashcode
from .models import User
from .import db
#current_user object is used to get the details of logged-in user, with support of 
from flask_login import login_user,login_required,logout_user,current_user

# from flask import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
ss = StandardScaler()
le = LabelEncoder()

import pickle

auth = Blueprint('auth',__name__)

model = pickle.load(open('model.pkl','rb'))
@auth.route('/login',methods=['POST','GET'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    user = User.query.filter_by(username=username).first()
    if user:
        if check_password_hash(user.password,password):
            flash('Successful Login',category='success')
            login_user(user,remember=True) #remeber here implements session of login
            return redirect(url_for('views.home'))
        else:
            flash('Incorrect Password!',category='error')
    else:
        flash('Invalid Username!',category='error')        
    return render_template("login.html",boolean=True)

@auth.route('/logout')
@login_required
def logout():
    logout_user()   
    return redirect(url_for('auth.login'))

@auth.route('/register',methods=['GET','POST'])
def register():
    #check if the input is post, assign the values from form
    if request.method=='POST':
        first_name = request.form.get('firstName')
        username = request.form.get('username')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        # print(username," ",first_name," ",password1)
        user = User.query.filter_by(username=username).first()#filter the database for the username and pick the fist occurance
        # validate if user account is already available
        if user:
            flash('Username Exists',category='error')
        #Validation of the input values
        elif len(first_name) < 4:
            flash('First Name has to be greater than 4 char',category='error')
        elif len(username) < 3:
            flash('Username has to be greater than 4 char',category='error')
        elif len(password1)<7:
            flash('Password has to be greater than 7 char',category='error')
        elif password1!= password2:
            flash('Password do not match',category='error')
        else:
            # Add user to database
            new_user = User(first_name=first_name,username=username,password=generate_password_hash(password1,method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user,remember=True)
            flash('Account Created',category='success')
            return redirect(url_for('views.home'))
        
    return render_template("register.html")

@auth.route('/predict',methods=['GET','POST'])
@login_required
def predict():
    
    if request.method=='POST':
                     
        #    new_feature = pd.DataFrame([request.form.values])
        #    feature ={"Gender":[request.form.get('Gender')],
        #              "Married":[request.form.get('Married')],
        #             "dependents":[request.form.get('dependents')],
        #             "Education":[request.form.get('Education')],
        #             "selfEmployed":[request.form.get('selfEmployed')],
        #             "applicationIncome":[float(request.form.get('applicationIncome'))],
        #             "coapplicantIncome":[float(request.form.get('coapplicantIncome'))],
        #             "loanAmt":[float(request.form.get('loanAmt'))],
        #             "loanTerm":[float(request.form.get('loanTerm'))],
        #             "creditHistory":[request.form.get('creditHistory')],
        #             "propertyArea":[request.form.get('propertyArea')]}
           feature2 ={"Gender":[request.form['Gender']],
                     "Married":[request.form['Married']],
                    "dependents":[request.form['dependents']],
                    "Education":[request.form['Education']],
                    "selfEmployed":[request.form['selfEmployed']],
                    "applicationIncome":[float(request.form['applicationIncome'])],
                    "coapplicantIncome":[float(request.form['coapplicantIncome'])],
                    "loanAmt":[float(request.form['loanAmt'])],
                    "loanTerm":[float(request.form['loanTerm'])],
                    "creditHistory":[request.form['creditHistory']],
                    "propertyArea":[request.form['propertyArea']]}
           df = pd.DataFrame(feature2)
          
        #  Encode categorical variables  
           cat_feature= df.select_dtypes(include='O').columns
           for c in cat_feature:
               df[c] = df[[c]].apply(le.fit_transform)
           print(df.head())
        # Standardize and scale the columns
           scaled_feature = ss.fit_transform(df.values)
           scaled_df = pd.DataFrame(scaled_feature,columns=df.columns,index=df.index)
           print(scaled_df.head())
           prediction = model.predict(scaled_feature)
           return render_template("predict.html",message='Predicted value is {}'.format(prediction),title="Loan Prediction")
   
    return render_template("predict.html")