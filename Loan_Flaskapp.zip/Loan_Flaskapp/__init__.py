from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy_utils import create_database, database_exists
from os import path
from flask_login import LoginManager


db = SQLAlchemy()
DB_NAME = "flaskdb"
USERNAME = "root"
PASSWORD = "WinZip#33"

def create_app():
    app = Flask(__name__)

#Import the Mysql database
    import pymysql
    pymysql.install_as_MySQLdb()

    app.config['SECRET_KEY']='toseeaworldinagrainofsandandheaveninawildflower'
    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql://{USERNAME}:{PASSWORD}@localhost:3306/{DB_NAME}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    
    #Initialize the database 
    db.init_app(app)    #Tell db which app it needs to use.
    
    from .views import views
    from .auth import auth
    from .models import User

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix = '/')
    
   
    with app.app_context():
        if not database_exists(db.engine.url):
            create_database(db.engine.url)
            db.create_all()
            print("Database Created")
        else:
            db.create_all()
            print("Database already exists") 

        #Initialize Login
    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'#Page opens up with login_page
    login_manager.init_app(app)
    
    @login_manager.user_loader
    def load_user(id):
        return User.query.get(int(id))    
    
    return app

# def create_database(app):
        

    # if not path.exists('Loan_Flaskapp/' + DB_NAME):
    #     db.create_all(app=app)
    #     print("Database Created !")
