from flask import Blueprint,render_template
from flask_login import login_required,current_user

# from flask import pickle
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
ss = StandardScaler()

# model = pickle.load(open('model.pkl','rb'))

views = Blueprint('views',__name__)

@views.route('/')
@login_required
def home():
    return render_template("home.html")
